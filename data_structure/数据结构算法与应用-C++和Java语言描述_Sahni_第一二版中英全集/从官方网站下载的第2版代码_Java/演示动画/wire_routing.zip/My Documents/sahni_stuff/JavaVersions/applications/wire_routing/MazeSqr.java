public class MazeSqr 
{
	public int x, y;
	public MazeSqr() { x = y = 0; }
}
