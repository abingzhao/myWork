public interface Queue
{
   public boolean isEmpty();
   public void put(int theElement);
   public int remove();
}
