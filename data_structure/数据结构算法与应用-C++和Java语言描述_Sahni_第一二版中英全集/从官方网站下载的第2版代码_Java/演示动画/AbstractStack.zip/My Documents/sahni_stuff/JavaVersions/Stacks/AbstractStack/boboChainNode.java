public class boboChainNode
{
   // package visible data members
   int element;
   boboChainNode next;

   // package visible constructors
   boboChainNode() {}
     
   boboChainNode(int element)
      {this.element = element;}

   boboChainNode(int element, boboChainNode next)
      {this.element = element;
       this.next = next;}
}// end boboChainNode
