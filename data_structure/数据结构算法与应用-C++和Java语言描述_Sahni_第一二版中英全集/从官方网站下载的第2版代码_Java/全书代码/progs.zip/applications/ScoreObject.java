/** A class that has an integer data member named score. */

package applications;

public class ScoreObject
{
   int score;

   /** constructor */
   public ScoreObject(int theScore)
      {score = theScore;}
}
