
package misc;

public class FloatAbc
{
   public static float abc(float a, float b, float c)
      {return a+b*c+b/c;}
   
   public static void main(String [] args)
      {System.out.println(abc(2, 3, 4));}
}
