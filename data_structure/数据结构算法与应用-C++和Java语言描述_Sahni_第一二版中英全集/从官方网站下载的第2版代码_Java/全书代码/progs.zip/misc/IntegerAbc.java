

package misc;

public class IntegerAbc
{
   public static int abc(int a, int b, int c)
      {return a+b*c+b/c;}
   
   public static void main(String [] args)
      {System.out.println(abc(2, 3, 4));}
}
