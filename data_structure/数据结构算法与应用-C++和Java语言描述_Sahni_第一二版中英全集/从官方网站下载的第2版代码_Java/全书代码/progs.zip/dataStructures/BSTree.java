
/** binary search tree */

package dataStructures;

public interface BSTree extends Dictionary
{
   public void ascend();
}
