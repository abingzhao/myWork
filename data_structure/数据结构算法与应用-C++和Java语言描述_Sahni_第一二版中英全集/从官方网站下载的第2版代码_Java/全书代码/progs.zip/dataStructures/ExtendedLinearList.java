

/** interface for extended linear lists */

package dataStructures;

public interface ExtendedLinearList extends LinearList
{
   public void clear();
   public void add(Object theElement);
}
