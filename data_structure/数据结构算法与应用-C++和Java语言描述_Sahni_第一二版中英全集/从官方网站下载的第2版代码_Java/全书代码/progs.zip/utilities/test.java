
package utilities;

public class test extends Dummy
{
int value;

public static void main(String [] args)
{
test a = new test();
test b = new test();
System.out.println(a.lessThan(b));
}
}
