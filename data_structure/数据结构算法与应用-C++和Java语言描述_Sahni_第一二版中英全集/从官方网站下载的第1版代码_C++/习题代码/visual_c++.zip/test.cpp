
#include <iostream.h>
#include <stdlib.h>
void main(void)
{
   cout << rand() << endl;
   cout << rand() << endl;
}
