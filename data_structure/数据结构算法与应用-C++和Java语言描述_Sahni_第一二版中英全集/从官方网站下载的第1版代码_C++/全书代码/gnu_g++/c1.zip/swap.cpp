// exchange values of two elements

#include <iostream.h>
#include "swap.h"

void main(void)
{
   int a = 2, b = 3;
   Swap(a,b);
   cout << a << ' ' << b << endl;
}


