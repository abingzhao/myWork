// time breadth first search

#include <iostream.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "ag.h"

void main(void)
{
   AdjacencyGraph G(100);
   int reach[101];
   int n = 100;
   for (int u = 1; u < n-1; u++)
      G.Add(u,u+1);
   clock_t start, finish;
   start = clock();
   for (int u = 1; u <= 4000; u++) {
      for (int j=1; j<=n; j++) reach[j] = 0;
      G.BFS(1, reach, 1);}
   finish = clock();
   cout << (finish - start)/CLK_TCK << endl;
   for (int u=1; u<=n; u++)
      cout << reach[u] << ' ';
   cout << endl;
}
