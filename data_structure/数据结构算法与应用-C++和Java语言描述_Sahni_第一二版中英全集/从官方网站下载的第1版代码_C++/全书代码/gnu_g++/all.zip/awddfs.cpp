// test depth first search on adjacency matrix weighted digraphs

#include <iostream.h>
#include "awd.h"

void main(void)
{
   AdjacencyWDigraph<int> G(7);
   int reach[8];
   int n = 7;
   cout << "enter number of edges" << endl;
   int e, u, v, w;
   cin >> e;
   for (int j =1; j <= e; j++) {
    cout << "enter edge " << j << endl;
    cin >> u >> v >> w;
    G.Add(u,v,w);}
   for (int j=1; j<=n; j++)
       reach[j] = 0;
   G.DFS(1, reach, 1);
   G.DFS(4, reach, 2);
   G.DFS(7, reach, 3);
   for (int j=1; j<=n; j++)
      cout << reach[j] << ' ';
   cout << endl;
}
