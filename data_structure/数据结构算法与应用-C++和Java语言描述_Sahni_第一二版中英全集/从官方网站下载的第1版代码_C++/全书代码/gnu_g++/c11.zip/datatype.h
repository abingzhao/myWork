#ifndef DataType_
#define DataType_

class DataType {
   friend void main(void);
   friend ostream& operator<<(ostream&, DataType);
   public:
      operator int() const {return key;}
//   private: g++ has a problem with main a friend
      int key;  // element key
      char ID;  // element identifier
};

ostream& operator<<(ostream& out, DataType x)
   {out << x.key << ' ' << x.ID << ' '; return out;}

#endif
