
#ifndef Node_
#define Node_

template <class T> class Chain;

class Node {
   friend void BinSort(Chain<Node>&, int);
   friend void main(void);
   public:
      operator int() const {return score;}
      int score;  // g++ has a problem with main being a friend
   private:
      char *name;
};

#endif
