
// functions for weighted networks

#ifndef WNetwork_
#define WNetwork_

#include "network.h"
#include "citer.h"
#include "jchain.h"

template <class T>
class WNetwork : virtual public Network
{
   public:
      virtual void First(int i, int& j, T& c) = 0;
      virtual void Next(int i, int& j, T& c) = 0;
      void BellmanFord(int s, T d[], int p[]);
};

template <class T>
void WNetwork<T>::BellmanFord(int s, T d[], int p[])
{// Shortest paths from vertex s, return shortest
 // distances in d and predecessor info in p.
 // Graph may have edges with negative cost but should
 // not have a cycle with negative cost.
   int n = Vertices();
   if (s < 1 || s > n) throw OutOfBounds();

   InitializePos();  // init graph iterator array
   // define two chains for vertices whose
   // d has changed
   Chain<int> *C1 = new Chain<T>;
   Chain<int> *C2 = new Chain<T>;
   // define an array to record vertices that are in C2
   bool *InC2 = new bool[n+1];

   // initialize p[1:n] = 0 and InC2[1:n] = false
   for (int i = 0; i <= n; i++) {
      p[i] = 0;
      InC2[i] = false;
      }
   p[s] = s;

   // initialize d[] = d^1() and C1
   // C1 will contain all vertices adjacent from s
   int u;
   T c;  // edge cost
   First(s, u, c);
   while (u) {
      d[u] = c;
      p[u] = s;
      C1->Insert(0,u);  // insert at front
      Next(s, u, c);
      }
   d[s] = 0;
   
   // do n - 2 rounds of updating d
   for (int k = 2; k < n; k++) {
      if (C1->IsEmpty()) break;  // no more changes possible
      // process vertices on C1
      while (!C1->IsEmpty()) {
         // get a vertex u whose d value has changed
         C1->Delete(1,u);  // delete from front

         // update d for the neighbors v of u
         int v;
         First(u, v, c);
         while (v) {
            if (!p[v] || d[u] + c < d[v]) {
               // this is either the first path to v
               // or is a shorter path than earlier ones
               d[v] = d[u] + c;
               p[v] = u;
               if (!InC2[v]) {
                  C2->Insert(0,v);
                  InC2[v] = true;
                  }
               }
            Next(u, v, c);
            }
         }

      // swap C1 and C2 for next update round
      Swap(C1, C2);

      // reset InC2[1:n] to false
      ChainIterator<int> c2;
      int *w = c2.Initialize(*C1);
      while (w) {
         InC2[*w] = false;
         w = c2.Next();
         }
      }

   delete C1;
   delete C2;
   DeactivatePos();
}

#endif;
