

// shell sort

#include <iostream.h>
#include "swap.h"

template <class T>
void ShellSort(T a[], int n)
{// Sort a[0:n-1] using the Shell sort method.

   int incr = n / 2;  // initial increment
   while (incr >= 1) {
      // insertion sort all sequences spaced by incr
      for (int i = incr; i < n; i++) {
         // insert a[i] into a[i - incr], a[i - 2*incr], ...
         T t = a[i];
         int j;
         for (j = i - incr; j >= 0 && t < a[j]; j -= incr)
            a[j + incr] = a[j];
         a[j + incr] = t;
         }

      // reduce increment by 2.2
      if (incr == 2) incr = 1;  // last increment must be 1
      else incr = incr / 2.2;
      }
}

void main(void)
{
   int y[10] = {10,7,8,9,4, 2, 3, 6, 5,1};
   ShellSort(y,10);
   for (int i = 0; i < 10; i++)
      cout << y[i] << ' ';
   cout << endl;
}
