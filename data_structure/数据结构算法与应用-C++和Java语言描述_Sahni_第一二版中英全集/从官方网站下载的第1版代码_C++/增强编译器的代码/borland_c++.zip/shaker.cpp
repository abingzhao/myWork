
// shaker sort

#include <iostream.h>
#include "swap.h"

template <class T>
void ShakerSort(T a[], int n)
{// Sort a[0:n-1] using the shaker sort method.
   for (int p = 1; p <= n/2; p++) {
      // phase p of shaker sort
      // first do left to right bubbling pass
      for (int i = p-1; i < n-p; i++)
         if (a[i] > a[i+1])
            Swap(a[i],a[i+1]);
     
      // now do right to left bubbling pass
      for (int i = n-p-1; i >= p; i--)
         if (a[i] < a[i-1])
            Swap(a[i],a[i-1]);
      }
}

void main(void)
{
   int y[10] = {10,7,8,9,4, 2, 3, 6, 5,1};
   ShakerSort(y,10);
   for (int i = 0; i < 10; i++)
      cout << y[i] << ' ';
   cout << endl;
}
