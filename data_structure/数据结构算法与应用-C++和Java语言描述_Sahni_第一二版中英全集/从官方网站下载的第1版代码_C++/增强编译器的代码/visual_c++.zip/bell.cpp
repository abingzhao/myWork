// single source shortest paths
// use Bellman-Ford Algorithm

#include <iostream.h>
#include "awd1.h"
#include "lwdg1.h"

void main(void)
{
   AdjacencyWDigraph<int> G(1);
   int dist[21], p[21], n, i;
   cin >> G;
   cout << "The input graph is" << endl;
   cout << G << endl;

   G.BellmanFord(1, dist, p);

   cout << "dist[i] and p[i] are" << endl;
   n = G.Vertices();
   for (i = 1; i <= n; i++)
      cout << dist[i] << ' ' << p[i] << endl;

   // try a linked graph
   LinkedWDigraph<int> H;
   cin >> H;
   cout << "The input graph is" << endl;
   cout << H << endl;

   H.BellmanFord(1, dist, p);

   cout << "dist[i] and p[i] are" << endl;
   n = H.Vertices();
   for (i = 1; i <= n; i++)
      cout << dist[i] << ' ' << p[i] << endl;

}
